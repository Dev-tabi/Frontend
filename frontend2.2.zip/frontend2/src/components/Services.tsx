import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import {
  HiCode,
  HiDeviceMobile,
  HiGlobe,
  HiLightningBolt,
  HiSupport,
  HiTemplate
} from 'react-icons/hi';

const Services: React.FC = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const services = [
    {
      icon: HiCode,
      title: 'React.js Development',
      description: 'Building modern, interactive web applications using React.js with clean, maintainable code.',
      features: ['React.js Applications', 'Component-based Architecture', 'State Management', 'Modern JavaScript (ES6+)'],
      color: 'from-blue-500 to-blue-600'
    },
    {
      icon: HiDeviceMobile,
      title: 'Responsive Design',
      description: 'Creating websites that look perfect and work flawlessly on all devices and screen sizes.',
      features: ['Mobile-First Design', 'Tablet Optimization', 'Desktop Enhancement', 'Cross-browser Compatibility'],
      color: 'from-green-500 to-green-600'
    },
    {
      icon: HiTemplate,
      title: 'WordPress CMS',
      description: 'Custom WordPress websites with easy-to-use content management for non-technical users.',
      features: ['Custom WordPress Themes', 'Content Management', 'Plugin Integration', 'Admin Training'],
      color: 'from-purple-500 to-purple-600'
    },
    {
      icon: HiGlobe,
      title: 'Frontend Development',
      description: 'Complete frontend solutions using HTML5, CSS3, JavaScript, and modern frameworks.',
      features: ['HTML5 & CSS3', 'JavaScript Development', 'Tailwind CSS', 'Interactive UI Components'],
      color: 'from-orange-500 to-orange-600'
    },
    {
      icon: HiLightningBolt,
      title: 'Website Optimization',
      description: 'Improving website speed, performance, and user experience for better conversions.',
      features: ['Speed Optimization', 'SEO-Friendly Code', 'Performance Tuning', 'Loading Speed Enhancement'],
      color: 'from-yellow-500 to-yellow-600'
    },
    {
      icon: HiSupport,
      title: 'Support & Maintenance',
      description: 'Ongoing website support, updates, and maintenance to keep your site running smoothly.',
      features: ['Regular Updates', 'Bug Fixes', 'Content Updates', 'Technical Support'],
      color: 'from-red-500 to-red-600'
    }
  ];

  const process = [
    {
      step: '01',
      title: 'Discovery & Planning',
      description: 'Understanding your requirements, goals, and target audience to create the perfect strategy.'
    },
    {
      step: '02',
      title: 'Design & Prototyping',
      description: 'Creating wireframes and designs that align with your brand and user experience goals.'
    },
    {
      step: '03',
      title: 'Development & Testing',
      description: 'Building your website with clean code, testing across devices, and ensuring quality.'
    },
    {
      step: '04',
      title: 'Launch & Support',
      description: 'Deploying your website and providing ongoing support and maintenance services.'
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delayChildren: 0.3,
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <section id="services" className="section-padding bg-gradient-to-br from-secondary-50 to-primary-50">
      <div className="container-custom">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
        >
          {/* Section Header */}
          <motion.div variants={itemVariants} className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-secondary-900 mb-4">
              My <span className="gradient-text">Services</span>
            </h2>
            <p className="text-xl text-secondary-600 max-w-3xl mx-auto">
              Comprehensive web development services to help your business succeed online with modern, professional solutions.
            </p>
          </motion.div>

          {/* Services Grid */}
          <motion.div
            variants={containerVariants}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20"
          >
            {services.map((service, index) => (
              <motion.div
                key={service.title}
                variants={itemVariants}
                className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 group"
                whileHover={{ scale: 1.02 }}
              >
                {/* Icon */}
                <div className="mb-6">
                  <div className={`w-16 h-16 bg-gradient-to-r ${service.color} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                    <service.icon className="h-8 w-8 text-white" />
                  </div>
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold text-secondary-900 mb-4">
                  {service.title}
                </h3>
                
                <p className="text-secondary-600 mb-6 leading-relaxed">
                  {service.description}
                </p>

                {/* Features */}
                <ul className="space-y-2">
                  {service.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center text-sm text-secondary-600">
                      <div className="w-2 h-2 bg-primary-500 rounded-full mr-3 flex-shrink-0"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </motion.div>

          {/* Process Section */}
          <motion.div variants={itemVariants} className="mb-16">
            <div className="text-center mb-12">
              <h3 className="text-2xl sm:text-3xl font-bold text-secondary-900 mb-4">
                My <span className="gradient-text">Process</span>
              </h3>
              <p className="text-secondary-600 max-w-2xl mx-auto">
                A proven methodology that ensures successful project delivery from start to finish.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {process.map((step, index) => (
                <motion.div
                  key={step.step}
                  variants={itemVariants}
                  className="text-center relative"
                >
                  {/* Step Number */}
                  <div className="mb-6 relative">
                    <div className="w-16 h-16 bg-gradient-to-r from-primary-500 to-primary-600 rounded-full flex items-center justify-center mx-auto">
                      <span className="text-white font-bold text-lg">{step.step}</span>
                    </div>
                    
                    {/* Connector Line */}
                    {index < process.length - 1 && (
                      <div className="hidden lg:block absolute top-8 left-full w-full h-0.5 bg-gradient-to-r from-primary-300 to-transparent"></div>
                    )}
                  </div>

                  <h4 className="text-lg font-semibold text-secondary-900 mb-3">
                    {step.title}
                  </h4>
                  
                  <p className="text-secondary-600 text-sm leading-relaxed">
                    {step.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* CTA Section */}
          <motion.div
            variants={itemVariants}
            className="text-center"
          >
            <div className="bg-white rounded-2xl p-8 shadow-lg max-w-3xl mx-auto">
              <h3 className="text-2xl font-bold text-secondary-900 mb-4">
                Ready to Start Your Project?
              </h3>
              <p className="text-secondary-600 mb-6 leading-relaxed">
                Let's discuss your requirements and create a custom solution that perfectly fits your needs and budget.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <motion.button
                  onClick={() => {
                    const element = document.querySelector('#contact');
                    if (element) {
                      element.scrollIntoView({ behavior: 'smooth' });
                    }
                  }}
                  className="btn-primary"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Get Free Quote
                </motion.button>
                
                <motion.a
                  href="mailto:tabisoomro12@gmail.com"
                  className="btn-secondary"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Email Me
                </motion.a>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default Services;
