import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import {
  SiHtml5,
  SiCss3,
  SiJavascript,
  SiReact,
  SiTailwindcss,
  SiWordpress,
  SiGit,
  SiFigma
} from 'react-icons/si';

const Skills: React.FC = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delayChildren: 0.3,
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5
      }
    }
  };

  const skills = [
    {
      name: 'HTML5',
      icon: SiHtml5,
      level: 95,
      color: 'from-orange-500 to-orange-600',
      description: 'Semantic markup and modern HTML5 features'
    },
    {
      name: 'CSS3',
      icon: SiCss3,
      level: 92,
      color: 'from-blue-500 to-blue-600',
      description: 'Advanced styling, animations, and responsive design'
    },
    {
      name: 'JavaScript',
      icon: SiJavascript,
      level: 88,
      color: 'from-yellow-500 to-yellow-600',
      description: 'ES6+, DOM manipulation, and modern JS features'
    },
    {
      name: 'React.js',
      icon: SiReact,
      level: 85,
      color: 'from-cyan-500 to-cyan-600',
      description: 'Hooks, Context API, and component architecture'
    },
    {
      name: 'Tailwind CSS',
      icon: SiTailwindcss,
      level: 90,
      color: 'from-teal-500 to-teal-600',
      description: 'Utility-first CSS framework and custom designs'
    },
    {
      name: 'WordPress CMS',
      icon: SiWordpress,
      level: 85,
      color: 'from-blue-600 to-blue-700',
      description: 'Custom themes, plugins, and content management'
    },
    {
      name: 'Git & GitHub',
      icon: SiGit,
      level: 80,
      color: 'from-gray-700 to-gray-800',
      description: 'Version control and collaborative development'
    },
    {
      name: 'Figma',
      icon: SiFigma,
      level: 75,
      color: 'from-purple-500 to-purple-600',
      description: 'UI/UX design and prototyping'
    }
  ];

  const categories = [
    {
      title: 'Frontend Technologies',
      skills: skills.slice(0, 5),
      description: 'Modern frontend technologies for building amazing user interfaces'
    },
    {
      title: 'CMS & Tools',
      skills: skills.slice(5),
      description: 'Content management systems and development tools'
    }
  ];

  return (
    <section id="skills" className="section-padding bg-gradient-to-br from-secondary-50 to-primary-50">
      <div className="container-custom">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
        >
          {/* Section Header */}
          <motion.div variants={itemVariants} className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-secondary-900 mb-4">
              My <span className="gradient-text">Skills</span>
            </h2>
            <p className="text-xl text-secondary-600 max-w-3xl mx-auto">
              A comprehensive toolkit of modern web technologies and frameworks that I use to bring ideas to life.
            </p>
          </motion.div>

          {/* Skills Categories */}
          <div className="space-y-16">
            {categories.map((category, categoryIndex) => (
              <motion.div
                key={category.title}
                variants={itemVariants}
                className="space-y-8"
              >
                <div className="text-center">
                  <h3 className="text-2xl font-bold text-secondary-900 mb-2">
                    {category.title}
                  </h3>
                  <p className="text-secondary-600">
                    {category.description}
                  </p>
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
                  {category.skills.map((skill, index) => (
                    <motion.div
                      key={skill.name}
                      variants={itemVariants}
                      className="skill-card group cursor-pointer"
                      whileHover={{ 
                        scale: 1.05,
                        rotateY: 5,
                      }}
                      transition={{ duration: 0.3 }}
                    >
                      <div className="text-center">
                        {/* Icon */}
                        <div className="mb-4 flex justify-center">
                          <div className={`w-16 h-16 bg-gradient-to-r ${skill.color} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                            <skill.icon className="h-8 w-8 text-white" />
                          </div>
                        </div>

                        {/* Skill Name */}
                        <h4 className="text-lg font-semibold text-secondary-900 mb-2">
                          {skill.name}
                        </h4>

                        {/* Description */}
                        <p className="text-sm text-secondary-600 mb-4">
                          {skill.description}
                        </p>

                        {/* Progress Bar */}
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-sm font-medium text-secondary-700">
                              Proficiency
                            </span>
                            <span className="text-sm font-bold text-primary-600">
                              {skill.level}%
                            </span>
                          </div>
                          <div className="w-full bg-secondary-200 rounded-full h-2">
                            <motion.div
                              className={`h-2 bg-gradient-to-r ${skill.color} rounded-full`}
                              initial={{ width: 0 }}
                              animate={inView ? { width: `${skill.level}%` } : { width: 0 }}
                              transition={{ 
                                duration: 1.5, 
                                delay: categoryIndex * 0.2 + index * 0.1,
                                ease: "easeOut"
                              }}
                            />
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>

          {/* Call to Action */}
          <motion.div
            variants={itemVariants}
            className="text-center mt-16"
          >
            <div className="bg-white rounded-2xl p-8 shadow-lg max-w-2xl mx-auto">
              <h3 className="text-2xl font-bold text-secondary-900 mb-4">
                Ready to Work Together?
              </h3>
              <p className="text-secondary-600 mb-6">
                Let's discuss how these skills can help bring your project to life.
              </p>
              <motion.button
                onClick={() => {
                  const element = document.querySelector('#contact');
                  if (element) {
                    element.scrollIntoView({ behavior: 'smooth' });
                  }
                }}
                className="btn-primary"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Start a Project
              </motion.button>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default Skills;
