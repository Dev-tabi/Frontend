import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { HiCode, HiLightningBolt, HiHeart, HiAcademicCap } from 'react-icons/hi';

const About: React.FC = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delayChildren: 0.3,
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5
      }
    }
  };

  const stats = [
    { number: '50+', label: 'Projects Completed' },
    { number: '3+', label: 'Years Experience' },
    { number: '100%', label: 'Client Satisfaction' },
    { number: '24/7', label: 'Support Available' },
  ];

  const highlights = [
    {
      icon: HiCode,
      title: 'Clean Code',
      description: 'Writing maintainable, scalable, and efficient code following best practices.'
    },
    {
      icon: HiLightningBolt,
      title: 'Fast Performance',
      description: 'Optimizing websites for speed and performance across all devices.'
    },
    {
      icon: HiHeart,
      title: 'User-Focused',
      description: 'Creating intuitive and engaging user experiences that convert.'
    },
    {
      icon: HiAcademicCap,
      title: 'Always Learning',
      description: 'Staying updated with the latest technologies and industry trends.'
    },
  ];

  return (
    <section id="about" className="section-padding bg-white">
      <div className="container-custom">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
        >
          {/* Section Header */}
          <motion.div variants={itemVariants} className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-secondary-900 mb-4">
              About <span className="gradient-text">Me</span>
            </h2>
            <p className="text-xl text-secondary-600 max-w-3xl mx-auto">
              Passionate web developer with expertise in modern technologies and a commitment to delivering exceptional digital experiences.
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Column - Profile Image */}
            <motion.div variants={itemVariants} className="order-2 lg:order-1">
              <div className="relative">
                <div className="w-80 h-80 mx-auto rounded-2xl overflow-hidden shadow-2xl bg-gradient-to-br from-blue-100 to-blue-200">
                  {/* Your profile photo */}
                  <img
                    src="/images/tabish-ali-profile.jpg.jpeg"
                    alt="Tabish Ali - Frontend Developer"
                    className="w-full h-full object-cover"
                    onLoad={() => console.log("✅ Tabish's profile image loaded successfully!")}
                    onError={(e) => {
                      console.log("❌ Profile image failed to load, using fallback");
                      e.currentTarget.src = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80";
                    }}
                  />
                </div>

                {/* Decorative elements */}
                <div className="absolute -top-4 -right-4 w-24 h-24 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full opacity-20"></div>
                <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-gradient-to-r from-blue-400 to-blue-500 rounded-full opacity-15"></div>
              </div>
            </motion.div>

            {/* Right Column - Text Content */}
            <motion.div variants={itemVariants} className="space-y-6 order-1 lg:order-2">
              <h3 className="text-2xl font-bold text-secondary-900 mb-4">
                Hi, I'm Tabish Ali
              </h3>
              
              <p className="text-secondary-600 leading-relaxed">
                I'm a passionate frontend web developer with expertise in creating modern,
                responsive websites and web applications. My journey in web development started with
                a curiosity about how beautiful websites work, and it has evolved into a deep passion for
                crafting stunning digital experiences that captivate users.
              </p>

              <p className="text-secondary-600 leading-relaxed">
                I specialize in frontend development using React.js, JavaScript, and modern CSS
                frameworks like Tailwind CSS. I also have extensive experience with CMS development,
                particularly WordPress, allowing me to create dynamic websites with easy content management.
              </p>

              <p className="text-secondary-600 leading-relaxed">
                My focus is on creating pixel-perfect, user-friendly interfaces that not only look amazing
                but also provide exceptional user experiences. I stay up-to-date with the latest frontend
                technologies and design trends to deliver cutting-edge solutions.
              </p>

              {/* Stats */}
              <div className="grid grid-cols-2 gap-6 pt-6">
                {stats.map((stat, index) => (
                  <motion.div
                    key={stat.label}
                    variants={itemVariants}
                    className="text-center"
                  >
                    <div className="text-3xl font-bold gradient-text mb-2">
                      {stat.number}
                    </div>
                    <div className="text-secondary-600 text-sm">
                      {stat.label}
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* Right Column - Highlights */}
            <motion.div variants={itemVariants} className="space-y-6">
              {highlights.map((highlight, index) => (
                <motion.div
                  key={highlight.title}
                  variants={itemVariants}
                  className="flex items-start space-x-4 p-6 bg-gradient-to-r from-primary-50 to-secondary-50 rounded-xl hover:shadow-lg transition-all duration-300"
                  whileHover={{ scale: 1.02 }}
                >
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-gradient-to-r from-primary-500 to-primary-600 rounded-lg flex items-center justify-center">
                      <highlight.icon className="h-6 w-6 text-white" />
                    </div>
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-secondary-900 mb-2">
                      {highlight.title}
                    </h4>
                    <p className="text-secondary-600">
                      {highlight.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default About;
