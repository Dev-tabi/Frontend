import React from 'react';
import { motion } from 'framer-motion';
import { HiArrowDown, HiCode, HiLightningBolt } from 'react-icons/hi';
import { FaGithub, FaLinkedin, FaEnvelope } from 'react-icons/fa';

const Hero: React.FC = () => {
  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delayChildren: 0.3,
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary-50 via-white to-secondary-50"></div>
      
      {/* Animated Background Shapes */}
      <motion.div
        animate={{
          rotate: 360,
          scale: [1, 1.1, 1],
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          ease: "linear"
        }}
        className="absolute top-20 right-20 w-32 h-32 bg-gradient-to-r from-primary-200 to-primary-300 rounded-full opacity-20"
      />
      
      <motion.div
        animate={{
          rotate: -360,
          scale: [1, 1.2, 1],
        }}
        transition={{
          duration: 25,
          repeat: Infinity,
          ease: "linear"
        }}
        className="absolute bottom-20 left-20 w-24 h-24 bg-gradient-to-r from-secondary-200 to-secondary-300 rounded-full opacity-20"
      />

      <div className="container-custom mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="text-center"
        >
          {/* Greeting */}
          <motion.div
            variants={itemVariants}
            className="mb-6"
          >
            <span className="inline-flex items-center px-4 py-2 bg-primary-100 text-primary-700 rounded-full text-sm font-medium">
              <HiLightningBolt className="mr-2 h-4 w-4" />
              Available for new projects
            </span>
          </motion.div>

          {/* Main Heading */}
          <motion.h1
            variants={itemVariants}
            className="text-4xl sm:text-5xl lg:text-7xl font-bold text-gray-900 mb-6"
          >
            Hi, I'm{' '}
            <span className="gradient-text">
              Tabish Ali
            </span>
          </motion.h1>

          {/* Subtitle */}
          <motion.h2
            variants={itemVariants}
            className="text-2xl sm:text-3xl lg:text-4xl font-semibold text-gray-700 mb-6"
          >
            Frontend Developer & CMS Specialist
          </motion.h2>

          {/* Value Proposition */}
          <motion.p
            variants={itemVariants}
            className="text-xl sm:text-2xl text-gray-600 mb-8 max-w-4xl mx-auto leading-relaxed"
          >
            I help businesses <span className="font-bold text-blue-600">increase online revenue by 40-60%</span> through modern,
            conversion-optimized websites that turn visitors into customers using{' '}
            <span className="font-semibold text-blue-600">React.js</span>,{' '}
            <span className="font-semibold text-blue-600">JavaScript</span>, and{' '}
            <span className="font-semibold text-blue-600">CMS development</span>
          </motion.p>

          {/* Social Proof */}
          <motion.div
            variants={itemVariants}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8 text-sm"
          >
            <div className="flex items-center bg-green-100 text-green-700 px-3 py-2 rounded-full">
              <span className="font-semibold">✅ 50+ Happy Clients</span>
            </div>
            <div className="flex items-center bg-blue-100 text-blue-700 px-3 py-2 rounded-full">
              <span className="font-semibold">⚡ 2-Hour Response</span>
            </div>
            <div className="flex items-center bg-purple-100 text-purple-700 px-3 py-2 rounded-full">
              <span className="font-semibold">🎯 100% Guarantee</span>
            </div>
          </motion.div>

          {/* CTA Buttons */}
          <motion.div
            variants={itemVariants}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12"
          >
            <motion.button
              onClick={() => scrollToSection('#case-studies')}
              className="bg-gradient-to-r from-blue-600 to-purple-600 text-white font-semibold py-4 px-8 rounded-lg transition-all duration-300 transform hover:scale-105 hover:shadow-lg inline-flex items-center"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <HiCode className="mr-2 h-5 w-5" />
              See Success Stories
            </motion.button>

            <motion.button
              onClick={() => scrollToSection('#pricing')}
              className="bg-transparent border-2 border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white font-semibold py-4 px-8 rounded-lg transition-all duration-300 inline-flex items-center"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <FaEnvelope className="mr-2 h-4 w-4" />
              View Pricing
            </motion.button>
          </motion.div>

          {/* Urgency */}
          <motion.div
            variants={itemVariants}
            className="text-center mb-8"
          >
            <div className="inline-flex items-center bg-red-100 text-red-700 px-4 py-2 rounded-full text-sm font-medium">
              🔥 Limited: Only 3 project spots available this month
            </div>
          </motion.div>

          {/* Social Links */}
          <motion.div
            variants={itemVariants}
            className="flex justify-center space-x-6 mb-12"
          >
            <motion.a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-secondary-600 hover:text-primary-600 transition-colors duration-200"
              whileHover={{ scale: 1.2, y: -2 }}
            >
              <FaGithub className="h-6 w-6" />
            </motion.a>
            
            <motion.a
              href="https://linkedin.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-secondary-600 hover:text-primary-600 transition-colors duration-200"
              whileHover={{ scale: 1.2, y: -2 }}
            >
              <FaLinkedin className="h-6 w-6" />
            </motion.a>
            
            <motion.a
              href="mailto:tabisoomro12@gmail.com"
              className="text-secondary-600 hover:text-primary-600 transition-colors duration-200"
              whileHover={{ scale: 1.2, y: -2 }}
            >
              <FaEnvelope className="h-6 w-6" />
            </motion.a>
          </motion.div>

          {/* Scroll Indicator */}
          <motion.div
            variants={itemVariants}
            className="flex justify-center"
          >
            <motion.button
              onClick={() => scrollToSection('#about')}
              className="text-secondary-400 hover:text-primary-600 transition-colors duration-200"
              animate={{ y: [0, 10, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <HiArrowDown className="h-8 w-8" />
            </motion.button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;
