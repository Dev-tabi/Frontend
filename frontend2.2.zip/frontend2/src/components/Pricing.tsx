import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { HiCheck, HiStar, HiLightningBolt, HiClock } from 'react-icons/hi';

const Pricing: React.FC = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const packages = [
    {
      name: 'Landing Page',
      price: '$500 - $1,200',
      duration: '3-5 days',
      description: 'Perfect single-page website for startups and small businesses to establish online presence',
      features: [
        'Modern, responsive design',
        'Mobile-optimized layout',
        'Contact form integration',
        'Basic SEO optimization',
        'Fast loading speed',
        'Social media links',
        '15-day support included'
      ],
      popular: false,
      color: 'from-blue-500 to-blue-600'
    },
    {
      name: 'Business Website',
      price: '$1,200 - $2,500',
      duration: '1-2 weeks',
      description: 'Multi-page professional website with modern frontend technologies',
      features: [
        'Multi-page website (5-8 pages)',
        'React.js frontend development',
        'Responsive design',
        'Interactive animations',
        'Contact forms',
        'Google Analytics setup',
        'Social media integration',
        '30-day support included'
      ],
      popular: true,
      color: 'from-purple-500 to-purple-600'
    },
    {
      name: 'CMS Website',
      price: '$2,000 - $4,000',
      duration: '2-3 weeks',
      description: 'WordPress CMS website with custom theme and easy content management',
      features: [
        'Custom WordPress theme',
        'Content management system',
        'Blog functionality',
        'Admin panel training',
        'Plugin integration',
        'SEO optimization',
        'Mobile responsive',
        '45-day support included'
      ],
      popular: false,
      color: 'from-green-500 to-green-600'
    },
    {
      name: 'Frontend Application',
      price: '$3,000 - $6,000',
      duration: '3-4 weeks',
      description: 'Advanced React.js frontend application with modern UI/UX',
      features: [
        'Custom React.js application',
        'Modern JavaScript (ES6+)',
        'State management (Redux/Context)',
        'API integration (frontend only)',
        'Advanced animations',
        'Performance optimization',
        'Cross-browser compatibility',
        '60-day support included'
      ],
      popular: false,
      color: 'from-red-500 to-red-600'
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delayChildren: 0.3,
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <section id="pricing" className="section-padding bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="container-custom">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
        >
          {/* Section Header */}
          <motion.div variants={itemVariants} className="text-center mb-16">
            <div className="inline-flex items-center bg-blue-100 text-blue-700 px-4 py-2 rounded-full text-sm font-medium mb-4">
              <HiLightningBolt className="mr-2 h-4 w-4" />
              Investment Packages
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
              Transparent <span className="gradient-text">Pricing</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
              Clear, upfront pricing with no hidden fees. Choose the package that fits your business needs and budget.
            </p>
            
            {/* Availability Badge */}
            <div className="inline-flex items-center bg-green-100 text-green-700 px-4 py-2 rounded-full text-sm font-medium">
              <HiClock className="mr-2 h-4 w-4" />
              Currently Booking: March 2025 • Limited to 3 projects per month
            </div>
          </motion.div>

          {/* Pricing Cards */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {packages.map((pkg, index) => (
              <motion.div
                key={pkg.name}
                variants={itemVariants}
                className={`relative bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 ${
                  pkg.popular ? 'ring-2 ring-purple-500 scale-105' : ''
                }`}
              >
                {pkg.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <div className="bg-purple-500 text-white px-4 py-2 rounded-full text-sm font-medium flex items-center">
                      <HiStar className="mr-1 h-4 w-4" />
                      Most Popular
                    </div>
                  </div>
                )}

                <div className="p-8">
                  {/* Package Header */}
                  <div className="text-center mb-6">
                    <div className={`w-16 h-16 bg-gradient-to-r ${pkg.color} rounded-xl flex items-center justify-center mx-auto mb-4`}>
                      <HiLightningBolt className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{pkg.name}</h3>
                    <div className="text-3xl font-bold text-gray-900 mb-2">{pkg.price}</div>
                    <div className="text-gray-500 text-sm">{pkg.duration} delivery</div>
                  </div>

                  {/* Description */}
                  <p className="text-gray-600 text-center mb-6 text-sm leading-relaxed">
                    {pkg.description}
                  </p>

                  {/* Features */}
                  <ul className="space-y-3 mb-8">
                    {pkg.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start">
                        <HiCheck className="h-5 w-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-600 text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  {/* CTA Button */}
                  <motion.button
                    onClick={() => {
                      const element = document.querySelector('#contact');
                      if (element) {
                        element.scrollIntoView({ behavior: 'smooth' });
                      }
                    }}
                    className={`w-full py-3 px-6 rounded-lg font-semibold transition-all duration-200 ${
                      pkg.popular
                        ? 'bg-purple-600 text-white hover:bg-purple-700'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    Get Started
                  </motion.button>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Additional Info */}
          <motion.div variants={itemVariants} className="text-center mt-16">
            <div className="bg-white rounded-2xl p-8 shadow-lg max-w-4xl mx-auto">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                Why Choose My Services?
              </h3>
              <div className="grid md:grid-cols-3 gap-6 text-center">
                <div>
                  <div className="text-3xl font-bold text-blue-600 mb-2">100%</div>
                  <div className="text-gray-600">Money-back guarantee if not satisfied</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-green-600 mb-2">24/7</div>
                  <div className="text-gray-600">Support during project development</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-purple-600 mb-2">∞</div>
                  <div className="text-gray-600">Unlimited revisions until you're happy</div>
                </div>
              </div>
              
              <div className="mt-8 p-6 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl">
                <p className="text-gray-700 mb-4">
                  <strong>Need a custom quote?</strong> Every project is unique. Let's discuss your specific requirements and I'll provide a detailed proposal within 24 hours.
                </p>
                <motion.button
                  onClick={() => {
                    const element = document.querySelector('#contact');
                    if (element) {
                      element.scrollIntoView({ behavior: 'smooth' });
                    }
                  }}
                  className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors duration-200 font-semibold"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Get Custom Quote
                </motion.button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default Pricing;
